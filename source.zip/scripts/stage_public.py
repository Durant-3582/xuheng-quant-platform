"""Allowlist source only. Cloud deployment never includes paid records, local holdings, or secrets."""
import argparse
import hashlib
import os
from pathlib import Path
import shutil
from zipfile import ZipFile,ZIP_DEFLATED

ROOT=Path(__file__).resolve().parents[1]


def stage(out):
    if out.exists() and list(out.iterdir()):raise ValueError('目标目录须为空。')
    out.mkdir(parents=True,mode=0o700,exist_ok=True)
    files=[ROOT/'streamlit_app.py',ROOT/'.streamlit/config.toml',ROOT/'static/site-id.txt',
           ROOT/'xuheng/browser_settings/index.html']
    for sub in ('xuheng','ingest','checks','scripts'):
        files.extend(sorted((ROOT/sub).glob('*.py')))
    private_secrets=[(ROOT/p).read_text().strip().encode() for p in
                     ('.private/tushare-token','.streamlit/.local-course-pass') if (ROOT/p).is_file()]
    if not private_secrets:raise ValueError('未找到本机凭据，无法进行泄密检查。')
    def audit(body):
        if any(raw in body for raw in private_secrets):raise ValueError('发现敏感值，终止打包。')
        body.decode('utf-8')
    bundle=out/'source.zip'
    with ZipFile(bundle,'w',ZIP_DEFLATED) as z:
        for f in files:
            data=f.read_bytes();audit(data);z.writestr(f.relative_to(ROOT).as_posix(),data)
        z.testzip()
    sha=hashlib.sha256(bundle.read_bytes()).hexdigest()
    access=hashlib.sha256((ROOT/'.streamlit/.local-course-pass').read_text().strip().encode()).hexdigest()
    app='''"""Streamlit entrypoint: execute the versioned source included in this code-only repository."""
import hashlib,os,sys,tempfile,runpy
from pathlib import Path
from zipfile import ZipFile
src=Path(__file__).resolve().parent/'source.zip'
sha='SOURCE_SHA'
base=Path(tempfile.gettempdir())/('xuheng-source-'+sha)
if not base.is_dir():
    if hashlib.sha256(src.read_bytes()).hexdigest()!=sha:raise RuntimeError('代码包校验失败')
    with tempfile.TemporaryDirectory(dir=base.parent) as tmp:
        stage=Path(tmp)/'source';stage.mkdir(mode=0o700)
        with ZipFile(src) as z:
            if any(Path(n).is_absolute() or '..' in Path(n).parts for n in z.namelist()):raise ValueError('无效的项目路径')
            z.extractall(stage)
        try:stage.rename(base)
        except OSError:
            if not base.is_dir():raise
os.environ.setdefault('XUHENG_ACCESS_SHA256','ACCESS_SHA')
os.environ.setdefault('XUHENG_PREVIEW_FROM_TUSHARE','1')
os.environ.setdefault('XUHENG_HOSTED_SAMPLE_DIR',str(Path(tempfile.gettempdir())/'xuheng-private-course-20261113-v1'))
if str(base) not in sys.path:
    sys.path.insert(0,str(base))
_ = runpy.run_path(str(base/'streamlit_app.py'),run_name='__main__')
'''
    content=app.replace('SOURCE_SHA',sha).replace("'ACCESS_SHA'",repr(access))
    audit(content.encode());(out/'streamlit_app.py').write_text(content)
    for name in ('README.md','requirements.txt','.streamlit/config.toml','static/site-id.txt'):
        (out/name).parent.mkdir(parents=True,exist_ok=True)
        audit((ROOT/name).read_bytes());shutil.copyfile(ROOT/name,out/name)
    print(f'可公开的源码文件 {len(files)} 个，部署目录 6 个文件，不含数据库或凭据。')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('out',type=Path);stage(parser.parse_args().out)
