from calendar import monthrange
from datetime import datetime,timedelta

import requests

from .archive import ArchiveError,CODE


def tushare(api,params,fields,token):
    if not token: raise ArchiveError("本期归档没有这项记录，服务器尚未配置用于补查的 Tushare 权限。")
    try:
        with requests.post("https://api.tushare.pro",json={"api_name":api,"token":token,"params":params,"fields":",".join(fields)},timeout=(5,20),allow_redirects=False) as response:
            response.raise_for_status();obj=response.json()
    except (requests.RequestException,ValueError) as exc:raise ArchiveError("暂时无法连接 Tushare，请稍后重试。") from exc
    if obj.get("code")!=0:raise ArchiveError("Tushare 未返回可用数据，请检查该接口的权限或调用频率。")
    data=obj.get("data") or {}
    if set(data.get("fields",[]))!=set(fields):raise ArchiveError("Tushare 返回的列与请求不一致。")
    return [dict(zip(data["fields"],row,strict=True)) for row in data["items"]]


def extra(s,kind,code,when,token,*,fetch=tushare):
    if code not in s.catalog or when>s.day or when<"20000101":raise ValueError("证券或查询日期无效。")
    cached=s.json(f"{kind}/{code}/{when}",optional=True)
    if cached is not None:return cached
    if kind=="financial":
        fields="ts_code ann_date end_date eps roe grossprofit_margin debt_to_assets".split()
        end=datetime.strptime(when,"%Y%m%d");past=end.year-3
        start=end.replace(year=past,day=min(end.day,monthrange(past,end.month)[1])).strftime("%Y%m%d")
        raw=fetch("fina_indicator",{"ts_code":code,"start_date":start,"end_date":when},fields,token)
        ranked=sorted((r for r in raw if r["ts_code"]==code and r["ann_date"] and r["ann_date"]<=when and r["end_date"] and r["end_date"]<=when),key=lambda r:(r["end_date"],r["ann_date"]),reverse=True)
        seen=set();rows=[]
        for r in ranked:
            if r["end_date"] not in seen:
                rows.append([r[k] for k in ("end_date","ann_date","eps","roe","grossprofit_margin","debt_to_assets")]);seen.add(r["end_date"])
            if len(rows)==8:break
        return rows
    if kind!="members":raise ValueError("未知的查询类别。")
    start=(datetime.strptime(when,"%Y%m%d")-timedelta(days=95)).strftime("%Y%m%d")
    fields="index_code con_code trade_date weight".split()
    latest="";by_code={};seen=set()
    for i in range(90):
        batch=fetch("index_weight",{"index_code":code,"start_date":start,"end_date":when,"limit":1000,"offset":1000*i},fields,token)
        marker=tuple((r["trade_date"],r["con_code"]) for r in batch)
        if batch and marker in seen:raise ArchiveError("指数成分分页重复，请稍后再试。")
        seen.add(marker)
        for r in batch:
            d,c=r["trade_date"],r["con_code"]
            if r["index_code"]!=code or not (start<=d<=when) or not CODE.fullmatch(c):raise ArchiveError("成分的代码或日期与请求不一致。")
            if d>latest:latest=d;by_code={}
            if d==latest:
                c=s.snapshot["aliases"].get(c,c)
                by_code[c]=[c,s.catalog[c][1] if c in s.catalog else None,r["weight"]]
        if len(batch)<1000:break
    else: raise ArchiveError("未能读取全部指数成分。")
    return {"day":latest,"items":sorted(by_code.values(),key=lambda row:row[2] or 0,reverse=True)}
